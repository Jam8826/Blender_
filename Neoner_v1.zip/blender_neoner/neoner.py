# Nikita Akimov
# interplanety@interplanety.org
#
# GitHub
#   https://github.com/Korchy/blender_neoner

import bpy
from mathutils import Vector
import math
from .b3d_lib_int.transform import Transform
from .curve_tools import BezierTools, CurveTools
from .holder import Holder
from .wall import Wall


class Neoner:

    _neoner_collection_name = 'neoner'

    @classmethod
    def make_neon(cls, context, active_object, width, height, tails_length, emission_color, use_holders, holders_frequency, holders_subdivision, use_wall, shape_type='FLAT'):
        if active_object and active_object.type in ['CURVE', 'FONT', 'MESH'] and active_object.select_get():
            current_mode = active_object.mode
            # convert object of any type to bezier curves
            cls._object_to_curve(source_object=active_object, width=width)
            # to bezier
            for spline in active_object.data.splines:
                if spline.type != 'BEZIER':
                    spline.type = 'BEZIER'
            # work with bezier curves
            if active_object.data.splines[0] and active_object.data.splines[0].bezier_points:   # some nurms can't convert to bezier splines
                bpy.ops.object.mode_set(mode='EDIT')
                if shape_type == 'FLAT':
                    for spline in active_object.data.splines:
                        if spline.use_cyclic_u:
                            p0 = spline.bezier_points[0]
                            p1 = spline.bezier_points[-1]
                            min_length = CurveTools.min_distance(point0=p0, point1=p1)
                            ratio = 1 - (min_length - 3 * width) / min_length
                            BezierTools.subdivide(p0=p0, p1=p1, bezier_spline=spline, ratio=ratio)
                            # break cycling
                            spline.use_cyclic_u = False
                # collections
                if use_holders or use_wall:
                    if cls._neoner_collection_name not in bpy.context.scene.collection.children:
                        cls._neoner_collection = bpy.data.collections.new(cls._neoner_collection_name)
                        context.scene.collection.children.link(cls._neoner_collection)
                # holders
                if use_holders and holders_frequency > 0:
                    # add holders
                    cls._add_holders(
                        context=context,
                        curve=active_object,
                        curve_width=width,
                        height=height,
                        holders_frequency=holders_frequency,
                        holders_subdivision=holders_subdivision
                    )
                # height
                if shape_type == 'FLAT':
                    for spline in active_object.data.splines:
                        # add points for making height
                        last_point = spline.bezier_points[-1]
                        last_point.handle_right_type = 'FREE'
                        last_point.handle_right = (last_point.co.x, last_point.co.y, last_point.co.z - height * 1 / 3)
                        co = (last_point.co.x, last_point.co.y, last_point.co.z - height)
                        hl = (last_point.co.x, last_point.co.y, last_point.co.z - height / 2)
                        hr = (last_point.co.x, last_point.co.y, last_point.co.z - height * 3 / 2)
                        BezierTools.append(bezier_spline=spline, cp_location=co, hl_location=hl, hr_location=hr)
                        first_point = spline.bezier_points[0]
                        first_point.handle_left_type = 'FREE'
                        first_point.handle_left = (first_point.co.x, first_point.co.y, first_point.co.z - height * 1 / 3)
                        co = (first_point.co.x, first_point.co.y, first_point.co.z - height)
                        hl = (first_point.co.x, first_point.co.y, first_point.co.z - height / 2)
                        hr = (first_point.co.x, first_point.co.y, first_point.co.z - height * 3 / 2)
                        BezierTools.prepend(bezier_spline=spline, cp_location=co, hl_location=hl, hr_location=hr)
                    # connect all splines together
                    while len(active_object.data.splines) > 1:
                        first_spline = active_object.data.splines[0]
                        p0 = first_spline.bezier_points[0]
                        p1 = first_spline.bezier_points[-1]
                        variants = []
                        for spline in active_object.data.splines:
                            if spline != first_spline:
                                variants.append((p0, spline.bezier_points[0], CurveTools.min_distance(point0=p0, point1=spline.bezier_points[0])))
                                variants.append((p1, spline.bezier_points[0], CurveTools.min_distance(point0=p1, point1=spline.bezier_points[0])))
                                variants.append((p0, spline.bezier_points[-1], CurveTools.min_distance(point0=p0, point1=spline.bezier_points[-1])))
                                variants.append((p1, spline.bezier_points[-1], CurveTools.min_distance(point0=p1, point1=spline.bezier_points[-1])))
                        variants_sorted = sorted(variants, key=lambda variant: variant[2])
                        nearest_points = variants_sorted[0]
                        BezierTools.deselect_all(spline_object=active_object)
                        nearest_points[0].select_control_point = True
                        nearest_points[1].select_control_point = True
                        bpy.ops.curve.make_segment()
                    # add left and right tales
                    p0 = active_object.data.splines[0].bezier_points[0]
                    p1 = active_object.data.splines[0].bezier_points[-1]
                    left_point = p0 if p0.co.x < p1.co.x else p1
                    co = (left_point.co.x - tails_length, left_point.co.y, left_point.co.z)
                    hl = (left_point.co.x - tails_length * 1 / 3, left_point.co.y, left_point.co.z)
                    hr = (left_point.co.x - tails_length * 2 / 3, left_point.co.y, left_point.co.z)
                    if left_point == p0:
                        BezierTools.prepend(bezier_spline=active_object.data.splines[0], cp_location=co, hl_location=hl, hr_location=hr)
                    else:
                        BezierTools.append(bezier_spline=active_object.data.splines[0], cp_location=co, hl_location=hl, hr_location=hr)
                    p0 = active_object.data.splines[0].bezier_points[0]
                    p1 = active_object.data.splines[0].bezier_points[-1]
                    right_point = p0 if p0.co.x > p1.co.x else p1
                    co = (right_point.co.x + tails_length, right_point.co.y, right_point.co.z)
                    hl = (right_point.co.x + tails_length * 1 / 3, right_point.co.y, right_point.co.z)
                    hr = (right_point.co.x + tails_length * 2 / 3, right_point.co.y, right_point.co.z)
                    if right_point == p0:
                        BezierTools.prepend(bezier_spline=active_object.data.splines[0], cp_location=co, hl_location=hl, hr_location=hr)
                    else:
                        BezierTools.append(bezier_spline=active_object.data.splines[0], cp_location=co, hl_location=hl, hr_location=hr)
                # width
                active_object.data.dimensions = '3D'
                active_object.data.fill_mode = 'FULL'
                active_object.data.bevel_depth = width
                # wall
                if use_wall:
                    cls._add_wall(context=context, curve=active_object, curve_width=width, height=height)
                # material
                material = cls._material(light_cut=height-width, emission_color=emission_color)
                active_object.active_material = material
                # bloom
                if context.scene.render.engine == 'BLENDER_EEVEE':
                    if not context.scene.eevee.use_bloom:
                        context.scene.eevee.use_bloom = True
                        context.scene.eevee.bloom_color = emission_color[:-1]
                        context.scene.eevee.bloom_intensity = 1.0
            # return mode
            bpy.ops.object.mode_set(mode=current_mode)

    @classmethod
    def _add_holders(cls, context, curve, curve_width, height, holders_frequency, holders_subdivision):
        # add holders object
        for spline in curve.data.splines:
            spline_length = BezierTools.spline_length(bezier_spline=spline, resolution=curve.data.resolution_u)
            holders_amount = math.floor(spline_length * holders_frequency)
            if holders_amount:
                Holder.add(context=context, scale=curve_width, height=height, link_to_scene=False)
                points_cloud = []
                p0_index = 0
                length_start = 0
                for i in [spline_length * i / holders_amount for i in range(holders_amount + 1)][1:-1]:   # don't use fist and last corner points
                    for index, point in enumerate(spline.bezier_points[p0_index + 1:]):
                        length = BezierTools.segment_length(point0=spline.bezier_points[p0_index], point1=point, resolution=curve.data.resolution_u)
                        if length + length_start > i:
                            ratio = (i - length_start) / length
                            # holder location
                            point_tmp = BezierTools.count_new_point_data(
                                point0_co=spline.bezier_points[p0_index].co,
                                point0_handle_right=spline.bezier_points[p0_index].handle_right,
                                point1_handle_left=point.handle_left,
                                point1_co=point.co,
                                t=ratio
                            )
                            # angle to follow spline (local z rotation)
                            tangent = (point_tmp[2] - point_tmp[3])
                            tangent.normalize()
                            vx = Vector((1.0, 0.0, 0.0))
                            if tangent.length != 0:
                                angle = vx.angle(tangent)
                                if tangent.y < vx.y:
                                    angle = math.pi - angle
                                points_cloud.append((point_tmp[2], angle))
                            break
                        else:
                            length_start += length
                            p0_index += 1
                if points_cloud:
                    holders_collection = next(iter([c for c in bpy.data.collections if c.name=='neoner_holders']), None)
                    if not holders_collection:
                        holders_collection = bpy.data.collections.new('neoner_holders')
                        context.scene.collection.children[cls._neoner_collection_name].children.link(holders_collection)
                    for p in points_cloud:
                        holder = Holder.add_instance(context=context, subsurf=True, subsurf_level=holders_subdivision, collection=holders_collection)
                        holder.matrix_world @= curve.matrix_world
                        holder.location = curve.matrix_world @ p[0]
                        Transform.rotate_object_local(obj=holder, axis='Z', angle=p[1])

    @classmethod
    def _add_wall(cls, context, curve, curve_width, height):
        # add wall plane
        wall_collection = next(iter([c for c in bpy.data.collections if c.name == 'neoner_wall']), None)
        if not wall_collection:
            wall_collection = bpy.data.collections.new('neoner_wall')
            context.scene.collection.children[cls._neoner_collection_name].children.link(wall_collection)
        Wall.add(context=context, curve=curve, curve_width=curve_width, height=height, collection=wall_collection)

    @staticmethod
    def _material(light_cut, emission_color):
        # add material
        material = bpy.data.materials.new(name='neoner_light')
        material.use_nodes = True
        # clear
        for node in material.node_tree.nodes:
            if not node.bl_idname in ['ShaderNodeOutputMaterial']:
                material.node_tree.nodes.remove(node)
        # add nodes
        output_node = next(iter([node for node in material.node_tree.nodes if node.name in ['Material Output']]), None)
        mix_node = material.node_tree.nodes.new(type='ShaderNodeMixShader')
        mix_node.location = (0.0, 0.0)
        emission_node = material.node_tree.nodes.new(type='ShaderNodeEmission')
        emission_node.location = (-200.0, 0.0)
        emission_node.inputs['Color'].default_value = emission_color
        glossy_node = material.node_tree.nodes.new(type='ShaderNodeBsdfGlossy')
        glossy_node.location = (-200.0, -200.0)
        glossy_node.inputs['Color'].default_value = (1.0, 1.0, 1.0, 1.0)
        glossy_node.inputs['Roughness'].default_value = 0.15
        layer_weight_node = material.node_tree.nodes.new(type='ShaderNodeLayerWeight')
        layer_weight_node.location = (-200.0, 200.0)
        layer_weight_node.inputs['Blend'].default_value = 0.7
        math_node_multiply = material.node_tree.nodes.new(type='ShaderNodeMath')
        math_node_multiply.location = (-400.0, 0.0)
        math_node_multiply.operation = 'MULTIPLY'
        value_node = material.node_tree.nodes.new(type='ShaderNodeValue')
        value_node.location = (-600.0, -300.0)
        value_node.outputs['Value'].default_value = 2.0
        value_node.label = 'Emission Strength'
        math_node_grater_than = material.node_tree.nodes.new(type='ShaderNodeMath')
        math_node_grater_than.location = (-600.0, 0.0)
        math_node_grater_than.operation = 'GREATER_THAN'
        math_node_grater_than.inputs[1].default_value = -light_cut
        separate_xyz_node = material.node_tree.nodes.new(type='ShaderNodeSeparateXYZ')
        separate_xyz_node.location = (-800.0, 0.0)
        texture_coordinates_node = material.node_tree.nodes.new(type='ShaderNodeTexCoord')
        texture_coordinates_node.location = (-1000.0, 0.0)
        # add links
        material.node_tree.links.new(mix_node.outputs['Shader'], output_node.inputs['Surface'])
        material.node_tree.links.new(layer_weight_node.outputs['Facing'], mix_node.inputs['Fac'])
        material.node_tree.links.new(emission_node.outputs['Emission'], mix_node.inputs[1])
        material.node_tree.links.new(glossy_node.outputs['BSDF'], mix_node.inputs[2])
        material.node_tree.links.new(math_node_multiply.outputs['Value'], emission_node.inputs['Strength'])
        material.node_tree.links.new(math_node_grater_than.outputs['Value'], math_node_multiply.inputs[0])
        material.node_tree.links.new(value_node.outputs['Value'], math_node_multiply.inputs[1])
        material.node_tree.links.new(separate_xyz_node.outputs['Z'], math_node_grater_than.inputs[0])
        material.node_tree.links.new(texture_coordinates_node.outputs['Object'], separate_xyz_node.inputs['Vector'])
        return material

    @staticmethod
    def _object_to_curve(source_object, width):
        # convert from object any type to curve
        if source_object and source_object.type in ['FONT', 'MESH']:
            if source_object.type == 'FONT':
                # font to curves
                if source_object.mode == 'EDIT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            elif source_object.type == 'MESH':
                # mesh to curves
                # apply transforms (rotation and scale)
                bpy.ops.object.transform_apply(location=False, scale=True, rotation=True)
                # remove faces
                if source_object.mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.delete(type='ONLY_FACE')
                bpy.ops.object.mode_set(mode='OBJECT')
                # move origin under geometry
                delta_z = sorted(source_object.data.vertices, key=lambda vert: vert.co[2])[0].co.z - width - 0.1    # lowest vertex.z - width - 0.1
                if delta_z < 0:
                    for vert in source_object.data.vertices:
                        vert.co.z -= delta_z
                    source_object.location.z += delta_z
            # to curve
            bpy.ops.object.convert(target='CURVE')
            source_object.data.dimensions = '3D'
