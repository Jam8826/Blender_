# Nikita Akimov
# interplanety@interplanety.org
#
# GitHub
#   https://github.com/Korchy/blender_neoner

from bpy.props import FloatProperty, PointerProperty, BoolProperty, IntProperty, FloatVectorProperty, EnumProperty
from bpy.types import Panel, PropertyGroup, WindowManager
from bpy.utils import register_class, unregister_class


class NEONER_PT_panel(Panel):
    bl_idname = 'NEONER_PT_panel'
    bl_label = 'Neoner'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Neoner'

    def draw(self, context):
        operator = self.layout.operator('neoner.make_neon', icon='LIGHT_SUN', text='Make Neon')
        operator.width = context.window_manager.neoner_vars.width
        operator.height = context.window_manager.neoner_vars.height
        operator.shape_type = context.window_manager.neoner_vars.shape_type
        operator.tails_length = context.window_manager.neoner_vars.tails_length
        operator.emission_color = context.window_manager.neoner_vars.emission_color
        operator.use_holders = context.window_manager.neoner_vars.use_holders
        operator.holders_frequency = context.window_manager.neoner_vars.holders_frequency
        operator.holders_subdivision = context.window_manager.neoner_vars.holders_subdivision
        operator.use_wall = context.window_manager.neoner_vars.use_wall
        self.layout.prop(context.window_manager.neoner_vars, 'width')
        self.layout.prop(context.window_manager.neoner_vars, 'height')
        self.layout.prop(context.window_manager.neoner_vars, 'shape_type', expand=True)
        self.layout.prop(context.window_manager.neoner_vars, 'tails_length')
        self.layout.prop(context.window_manager.neoner_vars, 'emission_color')
        self.layout.prop(context.window_manager.neoner_vars, 'use_holders')
        row = self.layout.row()
        if not context.window_manager.neoner_vars.use_holders:
            row.enabled = False
        col = row.column()
        col.prop(context.window_manager.neoner_vars, 'holders_frequency')
        col.prop(context.window_manager.neoner_vars, 'holders_subdivision')
        self.layout.prop(context.window_manager.neoner_vars, 'use_wall')
        box = self.layout.box()
        box.label(text='Bloom properties')
        box.prop(data=context.scene.eevee, property='bloom_radius')
        row = box.row()
        row.prop(data=context.scene.eevee, property='bloom_color')
        box.prop(data=context.scene.eevee, property='bloom_intensity', expand=True)


class NEONERVars(PropertyGroup):
    width: FloatProperty(
        name='Width',
        default=0.01,
        subtype='UNSIGNED',
        min=0
    )
    height: FloatProperty(
        name='Height',
        default=0.1,
        subtype='UNSIGNED',
        min=0
    )
    tails_length: FloatProperty(
        name='Tails length',
        default=1.0,
        subtype='UNSIGNED',
        min=0
    )
    emission_color: FloatVectorProperty(
         name='Emission color',
         subtype='COLOR',
         size=4,
         min=0.0,
         max=1.0,
         default=(0.2, 0.9, 1.0, 1.0)
    )
    use_holders: BoolProperty(
        name='Holders',
        default=True
    )
    holders_frequency: IntProperty(
        name='Holders frequency',
        default=1,
        subtype='UNSIGNED',
        min=1
    )
    holders_subdivision: IntProperty(
        name='Holders subdivision',
        default=1,
        subtype='UNSIGNED',
        min=0
    )
    use_wall: BoolProperty(
        name='Wall',
        default=True
    )
    shape_type: EnumProperty(
        items=[
            ('FLAT', 'FLAT', 'FLAT', 'FLAT', 0),
            ('VOLUME', 'VOLUME', 'VOLUME', 'VOLUME', 1)
        ],
        default='FLAT'
    )


def register():
    register_class(NEONERVars)
    WindowManager.neoner_vars = PointerProperty(type=NEONERVars)
    register_class(NEONER_PT_panel)


def unregister():
    unregister_class(NEONER_PT_panel)
    del WindowManager.neoner_vars
    unregister_class(NEONERVars)
