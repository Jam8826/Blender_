# Nikita Akimov
# interplanety@interplanety.org
#
# GitHub
#   https://github.com/Korchy/blender_neoner

from .addon import Addon
from . import neoner_ops
from . import neoner_panel

bl_info = {
    'name': 'Neoner',
    'category': 'All',
    'author': 'Nikita Akimov',
    'version': (1, 1, 1),
    'blender': (2, 83, 0),
    'location': '3D Viewport - N-Panel - Neoner',
    'wiki_url': 'https://b3d.interplanety.org/en/blender-add-on-neoner/',
    'tracker_url': 'https://b3d.interplanety.org/en/blender-add-on-neoner/',
    'description': 'by VFXMEd.COM Neoner - make neon from text/curves'
}


def register():
    if not Addon.dev_mode():
        neoner_ops.register()
        neoner_panel.register()
    else:
        print('It seems you are trying to use the dev version of the ' + bl_info['name'] + ' add-on. It may work not properly. Please download and use the release version!')


def unregister():
    if not Addon.dev_mode():
        neoner_panel.unregister()
        neoner_ops.unregister()


if __name__ == '__main__':
    register()
