# Nikita Akimov
# interplanety@interplanety.org
#
# GitHub
#   https://github.com/Korchy/blender_neoner

from bpy.props import FloatProperty, BoolProperty, IntProperty, FloatVectorProperty, EnumProperty
from bpy.types import Operator
from bpy.utils import register_class, unregister_class
from .neoner import Neoner


class NEONER_OT_make_neon(Operator):
    bl_idname = 'neoner.make_neon'
    bl_label = 'Neoner: Make neon'
    bl_description = 'Make neon'
    bl_options = {'REGISTER', 'UNDO'}

    width: FloatProperty(
        name='Width',
        default=0.01,
        subtype='UNSIGNED',
        min=0
    )
    height: FloatProperty(
        name='Height',
        default=0.1,
        subtype='UNSIGNED',
        min=0
    )
    shape_type: EnumProperty(
        items=[
            ('FLAT', 'FLAT', 'FLAT', 'FLAT', 0),
            ('VOLUME', 'VOLUME', 'VOLUME', 'VOLUME', 1)
        ],
        default='FLAT'
    )
    tails_length: FloatProperty(
        name='Tails length',
        default=1.0,
        subtype='UNSIGNED',
        min=0
    )
    emission_color: FloatVectorProperty(
         name='Emission color',
         subtype='COLOR',
         size=4,
         min=0.0,
         max=1.0,
         default=(0.2, 0.9, 1.0, 1.0)
    )
    use_holders: BoolProperty(
        name='Holders',
        default=True
    )
    holders_frequency: IntProperty(
        name='Holders amount',
        default=1,
        subtype='UNSIGNED',
        min=1
    )
    holders_subdivision: IntProperty(
        name='Holders subdivision',
        default=1,
        subtype='UNSIGNED',
        min=0
    )
    use_wall: BoolProperty(
        name='Wall',
        default=True
    )

    def execute(self, context):
        Neoner.make_neon(
            context=context,
            active_object=context.active_object,
            width=self.width,
            height=self.height,
            tails_length=self.tails_length,
            emission_color=self.emission_color,
            use_holders=self.use_holders,
            holders_frequency=self.holders_frequency,
            holders_subdivision=self.holders_subdivision,
            use_wall=self.use_wall,
            shape_type=self.shape_type
        )
        return {'FINISHED'}


def register():
    register_class(NEONER_OT_make_neon)


def unregister():
    unregister_class(NEONER_OT_make_neon)
