# Nikita Akimov
# interplanety@interplanety.org
#
# GitHub
#   https://github.com/Korchy/blender_neoner

import bpy
from .b3d_lib_int.transform import Transform


class Wall:

    @classmethod
    def add(cls, context, curve, curve_width, height, collection=None):
        # add wall
        wall_data = bpy.data.meshes.new('wall')
        wall_data.from_pydata(cls._verts(), [], cls._faces())
        wall_data.update()
        wall_object = bpy.data.objects.new('wall', wall_data)
        if collection:
            collection.objects.link(wall_object)
        else:
            context.scene.collection.objects.link(wall_object)
        # scale and location
        wall_object.matrix_world @= curve.matrix_world
        curve_center = Transform.bounding_box_center_local(obj=curve)
        for vert in wall_data.vertices:
            vert.co = (vert.co.x * 2 * curve.dimensions.x + curve_center[0], vert.co.y * 2 * curve.dimensions.y + curve_center[1], vert.co.z - (height - curve_width))
        # material
        material = cls._material()
        wall_object.active_material = material
        return wall_object

    @staticmethod
    def _verts():
        return [
            (0.5, 0.5, 0.0),
            (0.5, -0.5, 0.0),
            (-0.5, 0.5, 0.0),
            (-0.5, -0.5, 0.0)
        ]

    @staticmethod
    def _faces():
        return [
            [2, 3, 1, 0]
        ]

    @staticmethod
    def _material():
        # add material
        material = bpy.data.materials.new(name='neoner_wall')
        material.use_nodes = True
        principled_bsdf_node = next(iter([node for node in material.node_tree.nodes if node.name in ['Principled BSDF']]), None)
        if principled_bsdf_node:
            principled_bsdf_node.distribution = 'GGX'
            principled_bsdf_node.inputs['Base Color'].default_value = (0.1, 0.1, 0.1, 1.0)
            principled_bsdf_node.inputs['Metallic'].default_value = 0.9
            principled_bsdf_node.inputs['Specular'].default_value = 0.85
            principled_bsdf_node.inputs['Roughness'].default_value = 0.2
            principled_bsdf_node.inputs['IOR'].default_value = 2.5
        texture_coordinates_node = material.node_tree.nodes.new(type='ShaderNodeTexCoord')
        texture_coordinates_node.location = (-800.0, 0.0)
        mapping_node = material.node_tree.nodes.new(type='ShaderNodeMapping')
        mapping_node.location = (-600.0, 0.0)
        image_node = material.node_tree.nodes.new(type='ShaderNodeTexImage')
        image_node.location = (-400.0, 0.0)
        # links
        material.node_tree.links.new(texture_coordinates_node.outputs['Object'], mapping_node.inputs['Vector'])
        material.node_tree.links.new(mapping_node.outputs['Vector'], image_node.inputs['Vector'])
        return material
