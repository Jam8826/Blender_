# Neoner
Blender 3D add-on for easy creation of various neon signs, lamps, pointers, and lights.

<img src="https://b3d.interplanety.org/wp-content/upload_content/2019/10/preview_01_670x335-400x200.jpg">

Add-on functionality
-
- Add curve (shift + a – Curve) and form the desired shape, or add any text (shift + a – Text), or add mesh (shift + a - Mesh) to the scene.
- Pressing the “Make Neon” button in the add-on panel will convert the active object into a neon highlight.
- Add-on options allow adjusting the light color, tube thickness and location, the presence and number of holders and the background.

<img src="https://b3d.interplanety.org/wp-content/upload_content/2019/10/preview_02_670x335-400x200.jpg">

Current add-on version
-
1.1.1.

Blender versions
-
2.80, 2.81, 2.82, 2.83

Location
-
“3D Viewport” window – N-panel – the “Neoner” tab

Installation
-
- Get *.zip archive with the add-on distributive.
- The “Preferences” window — Add-ons — Install… — specify the downloaded archive.

Version history
-
1.1.1.
- Fixed error with 2d-3d curves type with imported curves

1.1.0.
- Added simple mesh conversion to the neon (FLAT/VOLUME radiobutton)
- Added some bloom preferences to the "Neoner" panel
- Improved emission material

1.0.0.
- This release.
